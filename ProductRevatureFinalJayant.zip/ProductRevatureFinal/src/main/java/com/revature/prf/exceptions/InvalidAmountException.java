package com.revature.prf.exceptions;

public class InvalidAmountException extends RuntimeException {
	public InvalidAmountException() {
		// TODO Auto-generated constructor stub
	}
	public InvalidAmountException(String msg) {
		super(msg);
}
	

}
